// This software is Copyright (C) 2020 Jonas Mehrbach.

#ifndef ShiftRegister_h
#define ShiftRegister_h

#include <stdlib.h>
#include <Arduino.h>
//#################################################################
//Praeprozessormakros fuer die uebersichtlichere Programmierung
#define BAUDRATE 115200

#define OFF LOW
#define ON HIGH
#define FILL 2

#define INPUT false
#define OUTPUT true

#define RESET LOW
#define SAVE HIGH
#define DATA_OUT HIGH

#define EXPANDER_PORT false

#define REGISTER_PORT true
#define QA 0
#define QB 1
#define QC 2
#define QD 3
#define QE 4
#define QF 5
#define QG 6
#define QH 7

//#################################################################
/*
Aufbau: Schieberegister 74HC595

       +-----+
  QB  -| o   |-  VCC
  QC  -|     |-  QA
  QD  -|     |-  DS
  QE  -|     |-  OE(neg)
  QF  -|     |-  ST_CP
  QG  -|     |-  SH_CP
  QH  -|     |-  MR(neg)
  GND -|     |-  QI
       +-----+

Legende:
+ VCC   ->  Spannungsversorgung (+) 2-5V
+ GND   ->  Spannungsversorgung (-) Masse 0V
+ QA-QH ->  Parallele Ausgaenge
+ QI    ->  Serieller Ausgang (Anbindung v. weiteren Register)
+ MR    ->  Master Reset (LOW aktiv)
+ SH_CP ->  Shiftregister Takteingang
+ ST_CP ->  Ausgangsregister Takteingang
+ OE    ->  Ausgang aktivieren (LOW aktiv)
+ DS    ->  Serieller Dateneingang
*/
class ShiftRegister
{
	private:
  	
  	//Vereinfachung, um nicht immer 'digitalWrite' zuschreiben
  	void _(int pin, int zustand);
  	
  	//Methode mit der das Shiftregisters die Bits des 'zustand'-arrays erheahlt
  	void fill_function(int modus);
  	
	public:
	//Objekt-Konstruktor
	ShiftRegister(int cl_shift, int cl_storage, int data_in, bool io_mod);
	
	//Methode um einzelnen Ausgang zu schalten
	bool registerWrite(int change_pin, bool io_mode);
	
	//Methode um alle Ausgaenge an zuschalten
	void allOn();
	
	//Methode um alle Ausgaenge aus zuschalten
	void allOff();
	
	//Methode um Status eines Ausgangs zu bekommen
	int getState(int pin);
	
	//Methode zur Datenvisualisierung [Baud: 115200]
	void visualize();
	
};
#endif
