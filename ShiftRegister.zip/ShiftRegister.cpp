// This software is Copyright (C) 2020 Jonas Mehrbach.

#include "ShiftRegister.h"

	int SH_CP;      //Shiftregister Takteingang
  	int ST_CP;      //Ausgangsregister Takteingang
  	int DS;         //Serieller Daten-Eingang
  	bool MODUS;		//Mit welcher Pinzahl Ausgang angestuert werden soll
  					//-> PORT_EXPANDER: 14-21; PORT_REGISTER: 0-7
  	
  	//Zustand, welchen Shiftregister erhaehlt
  	int zustand[]= {OFF,OFF,OFF,OFF,OFF,OFF,OFF,OFF};
//#################################################################
  	
ShiftRegister::ShiftRegister(int cl_shift, int cl_storage, int data_in, bool io_mod)
{
	SH_CP = cl_shift;
    ST_CP = cl_storage;
    DS = data_in;
    MODUS = io_mod;
    
	pinMode(SH_CP,OUTPUT);
    pinMode(ST_CP,OUTPUT);
    pinMode(DS,OUTPUT);
    	
    allOff();					//Alle Ausgangspins werden auf 'LOW' geschaltet
}
void _(int pin, int zustand){digitalWrite(pin, zustand);}

void shift_function(int modus)
{
    for(int i=7;i>=0; i--)
    {
   		_(ST_CP,RESET);     					//LOW-setzen des Ausgangsregisters
      	_(SH_CP,RESET);   						//LOW-setzen des Shiftregisters Takteingangs
      		
      	if(modus != FILL){zustand[i]=modus;} 	//Array wird komplett auf 'HIGH'/'LOW' gesetzt		
      	_(DS,zustand[i]);	    				//Pegel am DS wird auf 'HIGH'/'LOW' gesetzt
      		
      	_(SH_CP,SAVE);    						//Bit aus DS wird in Shiftregister geschoben
    }
    _(ST_CP,DATA_OUT);     						//Kopieren der Daten vom Shift- ins Ausgangsregister
}
  	
bool ShiftRegister::registerWrite(int change_pin, bool io_mode)
{
    if(MODUS==EXPANDER_PORT)					//Registerportansteuerung mit Argumenten zwischen 14-21
	{
		change_pin-=14;							//-14 um auf richtige Array Position zu kommen 0-7
	}
	
	if(change_pin<=QH && change_pin>=QA)
	{
		zustand[change_pin]= io_mode;			//Bitsetzung an der Stelle 'change_pin' des Arrays
		shift_function(FILL);					//Aufrufen der 'shift_function'
		return true;
	}
	else{return false;}
}
int ShiftRegister::getState(int pin)
{
	if(MODUS==EXPANDER_PORT)	//Registerportansteuerung mit Argumenten zwischen 14-21
	{
		pin-=14;				//-14 um auf richtige Array Position zu kommen 0-7
	}
	return zustand[pin];			
}
void ShiftRegister::allOn(){shift_function(ON);};

void ShiftRegister::allOff(){shift_function(OFF);};

void ShiftRegister::visualize()
{ 
    Serial.begin(BAUDRATE);
    Serial.println("\n###########74HC595###############################");
              		     Serial.println("          +--------+");
  	Serial.println((String)" QB ["+zustand[1]+"]  -| O      |-  VCC    [+2 bis +6V]");
  	Serial.println((String)" QC ["+zustand[2]+"]  -|        |-  QA     ["+zustand[0]+"]");
  	Serial.println((String)" QD ["+zustand[3]+"]  -|        |-  DS     [PIN: "+DS+"]");
  	Serial.println((String)" QE ["+zustand[4]+"]  -|        |-  OE(neg)[GND: 0V]");
 	Serial.println((String)" QF ["+zustand[5]+"]  -|        |-  ST_CP  [PIN: "+ST_CP+"]");
  	Serial.println((String)" QG ["+zustand[6]+"]  -|        |-  SH_CP  [PIN: "+SH_CP+"]");
  	Serial.println((String)" QH ["+zustand[7]+"]  -|        |-  MR(neg)[+2 bis +6V]");
  	Serial.println((String)" GND[0V] -|        |-  QI     [X]");
        	             Serial.println("          +--------+");
  	Serial.print(" Legende: \n ['1'/'0'] -> Pinzustand: HIGH/LOW \n [X] -> von Bibliothek");
  	Serial.println(" nicht verwendet \n [Pin: <nr.>] -> Pinanschluss am Mikrocontroller");
  	Serial.println("#################################################");
}
